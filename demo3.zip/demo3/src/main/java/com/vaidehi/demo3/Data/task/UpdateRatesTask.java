package com.vaidehi.demo3.Data.task;

import com.vaidehi.demo3.Data.domain.Demo3ConversionRate;
import com.vaidehi.demo3.Data.service.Demo3LookupService;
import com.vaidehi.demo3.Data.service.Demo3RateService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;

import java.util.Collection;

public class UpdateRatesTask {
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private Demo3LookupService ecbLookupService;

    @Autowired
    private Demo3RateService exchangeRateService;

    @Scheduled(fixedRateString = "${update.task.rate}")
    public void updateExchangeRates() {
        log.info("Updating exchange rates");
        try {
            Collection<Demo3ConversionRate> updatedRates = ecbLookupService.getUpdatedRates();
            exchangeRateService.updateRates(updatedRates);
            log.info("Rates updated");
        } catch (Exception e) {
            log.error("Cannot update rates", e);
        }
    }


}
