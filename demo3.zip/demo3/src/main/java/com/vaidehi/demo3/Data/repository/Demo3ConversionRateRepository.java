package com.vaidehi.demo3.Data.repository;

import com.vaidehi.demo3.Data.domain.Demo3ConversionRate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;

import java.util.Date;
import java.util.List;

public interface Demo3ConversionRateRepository extends JpaRepository<Demo3ConversionRate, Long>, JpaSpecificationExecutor<Demo3ConversionRate>, CrudRepository<Demo3ConversionRate, Long> {
    Demo3ConversionRate findByCurrency(String currency);


    List<Demo3ConversionRate> findAll();

    List<Demo3ConversionRate> findAllByDate(Date date);

    List<Demo3ConversionRate> findAllByCurrency(String currency);

    Demo3ConversionRate findByDateAndCurrency(Date date, String currency);

    void delete(Demo3ConversionRate exchangeRate);

}

